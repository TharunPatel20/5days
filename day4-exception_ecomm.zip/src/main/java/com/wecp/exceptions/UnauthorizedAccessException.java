package com.wecp.exceptions;

public class UnauthorizedAccessException {
    // implement unauthorized access exception here
}