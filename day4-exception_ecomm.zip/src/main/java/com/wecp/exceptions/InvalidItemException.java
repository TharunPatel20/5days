package com.wecp.exceptions;

public class InvalidItemException  {
    // implement invalid item exception here
}
