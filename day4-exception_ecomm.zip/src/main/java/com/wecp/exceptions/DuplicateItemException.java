package com.wecp.exceptions;

public class DuplicateItemException  {
    // implement duplicate item exception here
}