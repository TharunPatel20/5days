package com.wecp.exceptions;

public class InvalidQuantityException  {
    // implement invalid quantity exception here
}
