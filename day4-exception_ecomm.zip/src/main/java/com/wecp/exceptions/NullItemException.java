package com.wecp.exceptions;

public class NullItemException {
    // implement null item exception here
}