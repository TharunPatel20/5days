package com.wecp.exceptions;

public class InsufficientStockException  {
    // implement insufficent stock exception here
}