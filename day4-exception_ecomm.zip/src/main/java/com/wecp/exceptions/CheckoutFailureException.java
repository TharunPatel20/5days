package com.wecp.exceptions;

public class CheckoutFailureException  {
    // implement checkout failure exception here
}
