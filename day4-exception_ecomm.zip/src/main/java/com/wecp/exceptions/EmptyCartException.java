package com.wecp.exceptions;

public class EmptyCartException  {
    // implement empty cart exception here
}