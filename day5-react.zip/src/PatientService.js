import environment from "./environments/environment.ts"
const API_URL = environment.apiUrl;

export const getPatients = async () => {
//  get all patients using fetch call to json server
};

export const addPatient = async (newPatient) => {
//   add new patient by posting data to json server
};
