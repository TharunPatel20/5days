const environment = {
  production: false,
  apiUrl: window.location.origin.replace("5000", "3000")
};
export default environment;
