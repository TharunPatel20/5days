package com.wecp.supplychainapplication.entity;

import javax.persistence.*;

public class FoodItem {
    // implement the FoodItem entity here
}