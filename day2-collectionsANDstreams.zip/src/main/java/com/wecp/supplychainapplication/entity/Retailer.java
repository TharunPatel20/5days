package com.wecp.supplychainapplication.entity;


import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;


public class Retailer {
    // implement retailer entity here
}