package com.wecp.library_management_system_jwt.service;


import com.wecp.library_management_system_jwt.entity.Book;
import com.wecp.library_management_system_jwt.repository.BookRepository;
import org.springframework.stereotype.Service;

import javax.persistence.EntityNotFoundException;
import java.util.List;


public class BookService {


}

