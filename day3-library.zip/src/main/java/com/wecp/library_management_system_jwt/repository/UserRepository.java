package com.wecp.library_management_system_jwt.repository;

import com.wecp.library_management_system_jwt.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface UserRepository {

}

