package com.wecp.library_management_system_jwt.entity;

import javax.persistence.*;


public class Book {

}

