package com.wecp.library_management_system_jwt.controller;


import com.wecp.library_management_system_jwt.entity.Book;
import com.wecp.library_management_system_jwt.repository.BookRepository;
import com.wecp.library_management_system_jwt.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;


public class BookController {


}
